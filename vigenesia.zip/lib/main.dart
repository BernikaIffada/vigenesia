import 'package:flutter/material.dart';
import 'Screens/Login.dart';
void main() => runApp(
  MaterialApp(
 debugShowCheckedModeBanner: false,
 home: Login(), // <- Buat Class Baru yg bernama MyScreen di dalam lib bikin folder baru screens isinya MyScreen.dart
 ));
